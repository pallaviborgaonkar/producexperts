import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-what-it-is',
  templateUrl: './what-it-is.component.html',
  styleUrls: ['./what-it-is.component.css']
})
export class WhatItIsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
