export class LoginModule {

    constructor(
      public email: string,
      public password: string,
    ) {  }
  
  }